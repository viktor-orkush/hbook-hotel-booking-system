<?php

if(!defined('_ICALENDAR'))
{
	define('_ICALENDAR',1);
}

require_once(__DIR__ . '/includes/framework.php');
