<?php

namespace MPHB\Exceptions;

class NoEnoughExecutionTimeException extends MPHBException {}
